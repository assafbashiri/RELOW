from enum import Enum


class Gender(Enum):

    male = 1
    female = 2

