
class Step:
    def __init__(self, products_amount, price):
        self.products_amount = products_amount
        self.price = price

    def get_products_amount(self):
        return self.products_amount

    def get_price(self):
        return self.price

